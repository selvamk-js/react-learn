import Link from "next/link";
import Layout from "../components/Layout";
import Image from "next/image";
import { useState } from "react";
import { useRouter } from "next/router";

export default function Home({ pokemon }) {
  const router = useRouter();

  const [filteredPokemon, setFilteredPokemom] = useState(pokemon);

  const handleSearch = (event) => {
    const filtered = pokemon.filter((pokeman) =>
      pokeman.name.includes(event.target.value)
    );
    setFilteredPokemom(filtered);
  };

  return (
    <Layout title="NextJS Pokedex">
      <h1 className="text-4xl mb-8 text-center ">Pokemon</h1>
      <div className="md:flex-none w-96 order-2 sm:order-1 flex justify-center py-4 sm:py-0">
        <input
          type="text"
          className="input-text"
          placeholder="Search"
          onChange={handleSearch}
        />
      </div>
      <div className="grid gap-4 grid-cols-3 grid-rows-3">
        {filteredPokemon.map((pokeman, index) => {
          return (
            <div
              key={index}
              className="shadow-lg border p-4 border-grey my-2 hover:shadow-md capitalize grid items-center text-lg bg-gray-200 rounded-lg"
            >
              <Link href={`/pokemon?id=${index + 1}`}>
                <div className="flex flex-row">
                  <Image
                    width={150}
                    height={150}
                    src={pokeman.image}
                    alt={pokeman.name}
                    className="w-20 h-20 mr-3"
                  />
                  <div className="flex flex-col justify-center">
                    <p className="mr-2 font-bold text-2xl">{pokeman.name}</p>
                  </div>
                  {/* <button
                    onClick={() => router.push(`/pokemon?id=${index + 1}`)}
                  >
                    Test
                  </button> */}
                </div>
              </Link>
            </div>
          );
        })}
      </div>
    </Layout>
  );
}

export async function getStaticProps(context) {
  try {
    const res = await fetch("https://pokeapi.co/api/v2/pokemon?limit=150");
    const { results } = await res.json();
    const pokemon = results.map((pokeman, index) => {
      const paddedId = ("00" + (index + 1)).slice(-3);

      const image = `https://assets.pokemon.com/assets/cms2/img/pokedex/detail/${paddedId}.png`;
      return { ...pokeman, image };
    });
    return {
      props: { pokemon },
    };
  } catch (err) {
    console.error(err);
  }
}
