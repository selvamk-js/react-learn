import Head from "next/head";
import React from "react";

export default function Layout({ title, children }) {
  return (
    <div className="bg-gray-300">
      <Head>
        <title>{title}</title>
      </Head>
      <main className="container">{children}</main>
    </div>
  );
}
